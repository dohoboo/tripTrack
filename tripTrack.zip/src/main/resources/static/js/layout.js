//검색 기능
function enterkey() {
	if (window.event.keyCode == 13) {
		document.getElementById("searchForm").submit();
	}
}