package com.springboot.tripTrack.service;

import java.util.List;

import com.springboot.tripTrack.dto.TagDto;

public interface TagService {

	List<TagDto> getAllTag();

}
