package com.springboot.tripTrack.service;

import java.util.List;

import com.springboot.tripTrack.dto.LocationDto;

public interface LocationService {

	List<LocationDto> getAllLoc();

}
